=== PipiLikaPay Gateway ===
Contributors: PipiLikaPay
Tags: PipiLikaPay, bdpaymentgateway, payment, gateway, bkash, rocket, nagad, upay, cellfin, paypal, stripe, paddle, perfectmoney, easypaymentgateway
Requires at least: 4.4
Tested up to: 6.2.2
Stable Tag: 2.1.0
Requires PHP: 5.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

PipiLikaPay Plugin for WooCommerce.

== Description ==

PipiLikaPay WooCommerce Plugin. You can receive payment through your personal account with Automation.

== Features ==

* Icon on/of
* Digital Product
* Fee System
* Pay with QR Code
* And many more...

== Supported Gateways ==
* bKash
* Rocket
* Nagad
* Upay
* Cellfin
* Paypal
* Stripe
* Paddle
* Perfect Money
* Multiple Bank